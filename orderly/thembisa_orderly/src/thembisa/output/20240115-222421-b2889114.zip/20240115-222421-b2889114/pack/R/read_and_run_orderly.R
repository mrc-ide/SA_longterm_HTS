# Compiles and runs the Thembisa model
run_thembisa <- function(){
  system("./thembisa")
}

# Read output from Thembisa and assign column headers
# read_output <- function(output_name){
#   # Import output txt
#   output_txt <- paste(output_name, "txt", sep = ".")
#   output <- read.delim(output_txt, header=FALSE, row.names = 1)
#   names(output)[2:87] <- seq(1985, 2100)
#   # names(output)[1] <- "Simulation"
#   output <- output %>% select(-V2) 
#   t_output <- as.data.frame(t(output))
#   output <- as.data.frame(as_tibble(t_output, rownames = "Year"))
#   output$Year <- as.numeric(output$Year)
#   names(output)[2] <- "Simulation_1"
#   return(output$Simulation_1)
# }

edit_formatted_data <- function(formatted_data, parameter_name, new_values, starting_year=1985, final_year=2100){
  # select parameter using dictionary
  parameter <- formatted_data$data[,which(dictionary$name == parameter_name)]
  # Edit value
  for (i in ((starting_year+1)-1985):((final_year+1)-1985)){
    parameter[i] <- new_values
  }
  # reassign to formatted data
  parameter -> formatted_data$data[,which(dictionary$name == parameter_name)]
  return(formatted_data)
}

edit_formatted_data_incremental <- function(formatted_data, parameter_name, new_values, starting_year=1985, final_year=2100){
  # select parameter using dictionary
  parameter <- formatted_data$data[,which(dictionary$name == parameter_name)]
  # Edit value
  for (i in ((starting_year+1)-1985):((starting_year+1)-1985)){
    parameter[i] <- 0.2877 - ((0.2877 - new_values) * 0.5)
  }
  for (i in ((starting_year+2)-1985):((final_year+1)-1985)){
    parameter[i] <- new_values
  }
  # reassign to formatted data
  parameter -> formatted_data$data[,which(dictionary$name == parameter_name)]
  return(formatted_data)
}


read_thembisa_output <- function(output_name){
  output_txt <- paste(output_name, "txt", sep = ".")
  # output_txt <- paste("THEMBISAv18", output_txt, sep = "/")
  output <- read.delim(output_txt, header=FALSE, row.names = 1)
  output <- output %>% select(-V2)
  t_output <- t(output)
  output_new <- as.data.frame(as_tibble(t_output))
  names(output_new) <- seq_along(output_new)
  output_new$year <- seq(1985, 2100)
  pivot_longer(output_new, -year, names_to = "parameter_set")
}


read_thembisa_scenario <- function(output_names){
  temp <- lapply(output_names, read_thembisa_output)
  names(temp) <- output_names
  bind_rows(temp, .id = "indicator")
}

# run_thembisa_scenario <- function(pitc_reduction_year, output_names, base_rate_reduction){
#   ## read in input parameter file
#   data <- readLines("Rollout_Original.txt")
#   ## write unedited input parameter file
#   formatted_data <- format_data(data, dictionary)
#   if (!is.na(pitc_reduction_year)){
#     formatted_data <- edit_formatted_data_incremental(formatted_data, "rate_first_test_neg_fem_under_25", 
#                                                       new_values = 0.2877 * base_rate_reduction, 
#                                                       starting_year = pitc_reduction_year)
#   }
#   rollout <- convert_to_thembisa_format(formatted_data, data, dictionary)
#  write(rollout, "THEMBISAv18/Rollout.txt")
#   ## compile and model
#   run_thembisa()
#  read_thembisa_scenario(output_names)
# }

# run_thembisa_scenario_future_variable <- function(pitc_reduction_year, output_names, base_rate_reduction, 
#                                                   future_var_parameter, future_var_value, future_var_year){
#   data <- readLines("Rollout_Original.txt")
#   formatted_data2 <- format_data(data, dictionary)
#   formatted_data3 <- edit_formatted_data(formatted_data2, future_var_parameter, 
#                                          new_values = future_var_value/100, 
#                                          starting_year = future_var_year)
#   if (!is.na(pitc_reduction_year)){
#     # data2 <- readLines(here("THEMBISAv18/Rollout.txt"))
#     formatted_data3 <- edit_formatted_data_incremental(formatted_data3, 
#                                                        "rate_first_test_neg_fem_under_25", 
#                                                        new_values = 0.2877 * base_rate_reduction, 
#                                                        starting_year = pitc_reduction_year)
#   }
#   rollout <- convert_to_thembisa_format(formatted_data3, data, dictionary)
#   write(rollout, here("THEMBISAv18/Rollout.txt"))
#   ## compile and model
#   run_thembisa()
#   read_thembisa_scenario(output_names)
# }

# incremental reductions in condom usage
# to be included in run_thembisa_scenario_future_variables
# reduce_condom_usage_incremental  <- function(output_names, 
#                                              fsw_condom_usage_init,
#                                              st_condom_usage_init,
#                                              lt_condom_usage_init,
#                                              fsw_condom_usage_decrease, 
#                                              st_condom_usage_decrease,
#                                              lt_condom_usage_decrease,
#                                              condom_incr_years){
#   data <- readLines("Rollout_Original.txt")
#   formatted_data2 <- format_data(data, dictionary) # reads in original value in editable format
#   for (year in condom_incr_years){ #loops over each condom usage increase year and changes the proportion reduction of probability
#     formatted_data2 <- edit_formatted_data(formatted_data2, "reduction_condom_fsw", 
#                                            new_values = (1-fsw_condom_usage_decrease), 
#                                            starting_year = year)
#     formatted_data2 <- edit_formatted_data(formatted_data2, "reduction_condom_st", 
#                                            new_values = (1-st_condom_usage_decrease), 
#                                            starting_year = year)
#     formatted_data2 <- edit_formatted_data(formatted_data2, "reduction_condom_lt", 
#                                            new_values = (1-lt_condom_usage_decrease), 
#                                            starting_year = year)
#     fsw_condom_usage_decrease = fsw_condom_usage_init + fsw_condom_usage_decrease
#     # if condition prevents negative values for probabilities
#     if (fsw_condom_usage_decrease >= 1){
#       fsw_condom_usage_decrease <- 1 
#     }
#     st_condom_usage_decrease = st_condom_usage_init + st_condom_usage_decrease
#     if (st_condom_usage_decrease >= 1){
#       st_condom_usage_decrease <- 1
#     }
#     lt_condom_usage_decrease = lt_condom_usage_init + lt_condom_usage_decrease
#     if (lt_condom_usage_decrease >= 1){
#       lt_condom_usage_decrease <- 1
#     }
#   }
#   return(formatted_data2)
# }

# function to do reduction or increase of previous years probability / rate

edit_formatted_data_prev_year <- function(formatted_data, parameter_name, new_values, starting_year=1985, final_year=2100){
  # select parameter using dictionary
  parameter <- formatted_data$data[,which(dictionary$name == parameter_name)]
  # Edit value
  for (i in ((starting_year+1)-1985):((final_year+1)-1985)){
    parameter[i] <- parameter[i-1] * new_values
  }
  # reassign to formatted data
  parameter -> formatted_data$data[,which(dictionary$name == parameter_name)]
  return(formatted_data)
}

# to be included in run_thembisa_scenario_prev_year - reduces condom usage by a percentage of the previous year's
reduce_condom_usage_prev_year  <- function(formatted_data2, 
                                           output_names, 
                                           fsw_condom_usage_decrease, 
                                           st_condom_usage_decrease,
                                           lt_condom_usage_decrease,
                                           condom_decr_years){
  formatted_data2 <- formatted_data2
  data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary) # reads in original value in editable format
  for (year in condom_decr_years){ #loops over each condom usage decrease year and changes the proportion reduction of probability
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_fsw", 
                                                     new_values = (1-fsw_condom_usage_decrease), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_st", 
                                                     new_values = (1-st_condom_usage_decrease), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_lt", 
                                                     new_values = (1-lt_condom_usage_decrease), 
                                                     starting_year = year)
  }
  return(formatted_data2)
}

# to be included in run_thembisa_scenario_prev_year - increases condom usage by a percentage of the previous year's
increase_condom_usage_prev_year  <- function(formatted_data2, 
                                           output_names, 
                                           fsw_condom_usage_increase, 
                                           st_condom_usage_increase,
                                           lt_condom_usage_increase,
                                           condom_incr_years){
  # data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary) # reads in original value in editable format
  for (year in condom_incr_years){ #loops over each condom usage increase year and changes the proportion increase of probability
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_fsw", 
                                                     new_values = (1+fsw_condom_usage_increase), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_st", 
                                                     new_values = (1+st_condom_usage_increase), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "reduction_condom_lt", 
                                                     new_values = (1+lt_condom_usage_increase), 
                                                     starting_year = year)
  }
  return(formatted_data2)
}

# reduces ART interruption rate by a percentage of the previous year's rate
reduce_art_interruption_prev_year  <- function(formatted_data2, output_names, art_interrupt_rate_decrease, art_incr_years){
  # data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary)
  for (year in art_incr_years){
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_art_by_year", 
                                                     new_values = (1-art_interrupt_rate_decrease), 
                                                     starting_year = year)
    if (art_interrupt_rate_decrease >= 1){
      art_interrupt_rate_decrease <- 1 
    }
  }
  return(formatted_data2)
}

# increases ART interruption rate by a percentage of the previous year's rate
increase_art_interruption_prev_year  <- function(formatted_data2, output_names, art_interrupt_rate_increase, art_decr_years){
  # data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary)
  for (year in art_decr_years){
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_art_by_year", 
                                                     new_values = (1+art_interrupt_rate_increase ), 
                                                     starting_year = year)
  }
  return(formatted_data2)
}

edit_formatted_data_maintain <- function(formatted_data2, parameter_name, starting_year, final_year=2100){
  # select parameter using dictionary
  parameter <- formatted_data2$data[,which(dictionary$name == parameter_name)]
  # Edit value
  for (i in ((starting_year)-1985):((final_year)-1985)){
    parameter[i+1] <- parameter[i]
  }
  # reassign to formatted data
  parameter -> formatted_data2$data[,which(dictionary$name == parameter_name)]
  return(formatted_data2)
}

# to be included in run_thembisa_scenario_prev_year
# maintains art interruption rates after reducing it temporariliy
maintain_art_retention <- function(formatted_data2, 
                                  output_names, 
                                  art_maintenance_years){
  for (year in art_maintenance_years){ #loops over each condom usage maintenance year and makes all years the same value as last reduction
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_art_by_year", 
                                                    starting_year = year)
    
  }
  return(formatted_data2)
}

# maintains condom usage after reducing it temporariliy
maintain_condom_usage <- function(formatted_data2, 
                                  output_names, 
                                  condom_maintenance_years){
  for (year in condom_maintenance_years){ #loops over each condom usage maintenance year and makes all years the same value as last reduction
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "reduction_condom_fsw", 
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "reduction_condom_st", 
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "reduction_condom_lt",
                                                    starting_year = year)
  }
  return(formatted_data2)
}

# reduce VMMC

change_mmc_prev_year  <- function(formatted_data,
                                  output_names,
                                  rel_rate_mmc_10_to_14_yr,
                                  rel_rate_mmc_15_to_19_yr,
                                  rel_rate_mmc_20_to_24_yr,
                                  rel_rate_mmc_25_to_49_yr,
                                  rel_rate_mmc_over_50_yr,
                                  mmc_change_years,
                                  mmc_rel_rate){
  # data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary) # reads in original value in editable format
  for (year in mmc_change_years){ #loops over each condom usage decrease year and changes the proportion reduction of probability
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data, "rel_rate_mmc_10_to_14_yr", 
                                                     new_values = (1 - mmc_rel_rate), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_mmc_15_to_19_yr", 
                                                     new_values = (1 - mmc_rel_rate), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_mmc_20_to_24_yr", 
                                                     new_values = (1 - mmc_rel_rate), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_mmc_25_to_49_yr", 
                                                     new_values = (1 - mmc_rel_rate), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_mmc_over_50_yr", 
                                                     new_values = (1 - mmc_rel_rate), 
                                                     starting_year = year)
  }
  return(formatted_data2)
}

# maintains mmc after reducing it temporariliy
maintain_mmc <- function(formatted_data2, 
                                  output_names, 
                                  mmc_maintenance_years){
  for (year in mmc_maintenance_years){ #loops over each condom usage maintenance year and makes all years the same value as last reduction
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_mmc_10_to_14_yr", 
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_mmc_15_to_19_yr", 
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_mmc_20_to_24_yr",
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_mmc_25_to_49_yr",
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_mmc_over_50_yr",
                                                    starting_year = year)
  }
  return(formatted_data2)
}

# reduce PrEP

change_prep_prev_year  <- function(formatted_data,
                                  output_names,
                                  rel_rate_prep_msm_over_20,
                                  rel_rate_prep_women_over_20,
                                  prep_change_years,
                                  prep_rel_rate){
  # data <- readLines("Rollout_Original.txt")
  # formatted_data2 <- format_data(data, dictionary) # reads in original value in editable format
  for (year in prep_change_years){ #loops over each prep decrease year and changes the proportion reduction of probability
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data, "rel_rate_prep_msm_over_20", 
                                                     new_values = (1 - prep_rel_rate), 
                                                     starting_year = year)
    formatted_data2 <- edit_formatted_data_prev_year(formatted_data2, "rel_rate_prep_women_over_20", 
                                                     new_values = (1 - prep_rel_rate), 
                                                     starting_year = year)
    
  }
  return(formatted_data2)
}

# maintains prep after reducing it temporariliy
maintain_prep <- function(formatted_data2, 
                         output_names, 
                         prep_maintenance_years){
  for (year in prep_maintenance_years){ #loops over each prep maintenance year and makes all years the same value as last reduction
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_prep_msm_over_20", 
                                                    starting_year = year)
    formatted_data2 <- edit_formatted_data_maintain(formatted_data2, "rel_rate_prep_women_over_20", 
                                                    starting_year = year)
  }
  return(formatted_data2)
}

run_thembisa_scenario_prev_year <- function(pitc_reduction_year,
                                            condom_usage_reduction,
                                            fsw_condom_usage_decrease, 
                                            st_condom_usage_decrease,
                                            lt_condom_usage_decrease,
                                            condom_decr_years,
                                            condom_usage_promotion,
                                            fsw_condom_usage_increase, 
                                            st_condom_usage_increase,
                                            lt_condom_usage_increase,
                                            condom_incr_years,
                                            condom_maintenance_years,
                                            art_coverage_increase,
                                            art_interrupt_rate_decrease,
                                            art_incr_years,
                                            art_coverage_decrease,
                                            art_interrupt_rate_increase,
                                            art_decr_years,
                                            art_maintenance_years,
                                            change_mmc,
                                            mmc_rel_rate,
                                            mmc_change_years,
                                            mmc_maintenance_years,
                                            change_prep,
                                            prep_rel_rate,
                                            prep_change_years,
                                            prep_maintenance_years,
                                            output_names, 
                                            base_rate_reduction){
  data <- readLines("Rollout_Original.txt")
  formatted_data2 <- format_data(data, dictionary)
  if (art_coverage_increase == TRUE){
    formatted_data2 <- reduce_art_interruption_prev_year(formatted_data2,
                                                         output_names, 
                                                           art_interrupt_rate_decrease, 
                                                           art_incr_years)
    formatted_data2 <- maintain_art_retention(formatted_data2, output_names, 
                                              art_maintenance_years)
  }
  if (art_coverage_decrease == TRUE){
    formatted_data2 <- increase_art_interruption_prev_year(formatted_data2,
                                                           output_names,
                                                           art_interrupt_rate_increase,
                                                           art_decr_years)
    formatted_data2 <- maintain_art_retention(formatted_data2, output_names, 
                                              art_maintenance_years)
  }
  if (condom_usage_reduction == TRUE){
    formatted_data2 <- reduce_condom_usage_prev_year(formatted_data2, output_names,
                                                     fsw_condom_usage_decrease, 
                                                     st_condom_usage_decrease,
                                                     lt_condom_usage_decrease,
                                                     condom_decr_years)
    formatted_data2 <- maintain_condom_usage(formatted_data2, output_names,
                                                     condom_maintenance_years)
  }
  if (condom_usage_promotion == TRUE){
    formatted_data2 <- increase_condom_usage_prev_year(formatted_data2, output_names,
                                                     fsw_condom_usage_increase, 
                                                     st_condom_usage_increase,
                                                     lt_condom_usage_increase,
                                                     condom_incr_years)
    formatted_data2 <- maintain_condom_usage(formatted_data2, output_names,
                                             condom_maintenance_years)
  }
  # if (change_mmc == TRUE & change_prep == FALSE){
  #   formatted_data2 <- change_mmc_prev_year(formatted_data2, output_names,
  #                                           rel_rate_mmc_10_to_14_yr,
  #                                           rel_rate_mmc_15_to_19_yr,
  #                                           rel_rate_mmc_20_to_24_yr,
  #                                           rel_rate_mmc_25_to_49_yr,
  #                                           rel_rate_mmc_over_50_yr,
  #                                           mmc_change_years,
  #                                           mmc_rel_rate)
  #   formatted_data2 <- maintain_mmc(formatted_data2, output_names,
  #                                            mmc_maintenance_years)
  #   
  # }
  # if (change_prep == TRUE & change_mmc == FALSE){
  #   formatted_data2 <- change_prep_prev_year(formatted_data2, output_names,
  #                                            rel_rate_prep_msm_over_20,
  #                                            rel_rate_prep_women_over_20,
  #                                            prep_change_years,
  #                                            prep_rel_rate)
  #   formatted_data2 <- maintain_prep(formatted_data2, output_names,
  #                                    prep_maintenance_years)
  # }
  # if (change_mmc & change_prep){
  #   formatted_data2 <- change_mmc_prev_year(formatted_data2, output_names,
  #                                           rel_rate_mmc_10_to_14_yr,
  #                                           rel_rate_mmc_15_to_19_yr,
  #                                           rel_rate_mmc_20_to_24_yr,
  #                                           rel_rate_mmc_25_to_49_yr,
  #                                           rel_rate_mmc_over_50_yr,
  #                                           mmc_change_years,
  #                                           mmc_rel_rate)
  #   formatted_data2 <- maintain_mmc(formatted_data2, output_names,
  #                                   mmc_maintenance_years)
  #   formatted_data2 <- change_prep_prev_year(formatted_data2, output_names,
  #                                            rel_rate_prep_msm_over_20,
  #                                            rel_rate_prep_women_over_20,
  #                                            prep_change_years,
  #                                            prep_rel_rate)
  #   formatted_data2 <- maintain_prep(formatted_data2, output_names,
  #                                    prep_maintenance_years)
  # }
  if (!is.na(pitc_reduction_year)){
    formatted_data2 <- edit_formatted_data_incremental(formatted_data2, 
                                                       "rate_first_test_neg_fem_under_25", 
                                                       new_values = 0.2877 * base_rate_reduction, 
                                                       starting_year = pitc_reduction_year)
  }
  rollout <- convert_to_thembisa_format(formatted_data2, data, dictionary)
  write(rollout, "Rollout.txt")
  ## compile and model
  run_thembisa()
  read_thembisa_scenario(output_names)
}

read_thembisa_results_cluster <- function(pitc_reduction_years, pitc_reduction_percentage, scenarios, 
                                          scenario_names, baseline){
  names(scenarios) <- scenario_names
  bind_rows(scenarios, .id = "pitc_reduction_year") %>% 
    dplyr::rename(intervention = value) %>% 
    dplyr::left_join(baseline) %>% 
    dplyr::rename(baseline = value) %>% 
    separate(pitc_reduction_year, c("pitc_reduction_year", "test_reduction")) %>% 
    tidyr::pivot_longer(c(intervention, baseline), names_to = "scenario")
}


# incremental reductions in art interruption rate
# to be included in run_thembisa_scenario_future_variables
# reduce_art_interruption_incremental  <- function(output_names, art_interrupt_init, art_interrupt_rate_decrease, art_incr_years){
#   data <- readLines("Rollout_Original.txt")
#   formatted_data2 <- format_data(data, dictionary)
#   for (year in art_incr_years){
#     formatted_data2 <- edit_formatted_data(formatted_data2, "rel_rate_art_by_year", 
#                                            new_values = (1-art_interrupt_rate_decrease), 
#                                            starting_year = year)
#     art_interrupt_rate_decrease = art_interrupt_init + art_interrupt_rate_decrease
#     if (art_interrupt_rate_decrease >= 1){
#       art_interrupt_rate_decrease <- 1 
#     }
#   }
#   return(formatted_data2)
# }
# 
# run_thembisa_scenario_future_variables <- function(pitc_reduction_year, 
#                                                    fsw_condom_usage_init,
#                                                    st_condom_usage_init,
#                                                    lt_condom_usage_init,
#                                                    fsw_condom_usage_decrease, 
#                                                    st_condom_usage_decrease,
#                                                    lt_condom_usage_decrease,
#                                                   condom_incr_years,
#                                                   art_interrupt_rate_decrease,
#                                                   art_interrupt_init,
#                                                   art_incr_years,
#                                                   output_names, 
#                                                   base_rate_reduction){
#   data <- readLines("Rollout_Original.txt")
#   formatted_data2 <- format_data(data, dictionary)
#   if (!is.na(art_interrupt_rate_decrease)){
#     formatted_data2 <- reduce_art_interruption_incremental(output_names,
#                                                            art_interrupt_init, 
#                                                            art_interrupt_rate_decrease, 
#                                                            art_incr_years)
#   }
#   if (!is.na(condom_incr_years)){
#     formatted_data2 <- reduce_condom_usage_incremental(output_names,
#                                                        fsw_condom_usage_init,
#                                                        st_condom_usage_init,
#                                                        lt_condom_usage_init,
#                                                        fsw_condom_usage_decrease, 
#                                                        st_condom_usage_decrease,
#                                                        lt_condom_usage_decrease,
#                                                       condom_incr_years)
#     
#   }
#   if (!is.na(pitc_reduction_year)){
#     formatted_data2 <- edit_formatted_data_incremental(formatted_data2, 
#                                                        "rate_first_test_neg_fem_under_25", 
#                                                        new_values = 0.2877 * base_rate_reduction, 
#                                                        starting_year = pitc_reduction_year)
#   }
#   rollout <- convert_to_thembisa_format(formatted_data2, data, dictionary)
#   write(rollout, here("THEMBISAv18/Rollout.txt"))
#   ## compile and model
#   run_thembisa()
#   read_thembisa_scenario(output_names)
# }

read_thembisa_results <- function(pitc_reduction_years){
  filepaths <- paste0("results/scenario_", pitc_reduction_years, ".csv")
  temp <- lapply(filepaths, read.csv)
  names(temp) <- pitc_reduction_years
  baseline <- read.csv("results/baseline.csv")
  bind_rows(temp, .id = "pitc_reduction_year") %>% 
    dplyr::rename(intervention = value) %>% 
    dplyr::left_join(baseline) %>% 
    dplyr::rename(baseline = value) %>% 
    tidyr::pivot_longer(c(intervention, baseline), names_to = "scenario")
}

read_thembisa_results_sliding_scale <- function(pitc_reduction_years, pitc_reduction_percentage){
  for (i in 1: length(pitc_reduction_percentage)){
    if (i == 1){
      filepaths <- paste0("results/scenario_", pitc_reduction_years, "_", pitc_reduction_percentage[i], ".csv")
    }
    if (i > 1){
      filepaths <- append(filepaths, paste0("results/scenario_", pitc_reduction_years, "_", pitc_reduction_percentage[i], ".csv"))
    }
  }
  temp <- lapply(filepaths, read.csv)
  
  for (i in 1: length(pitc_reduction_percentage)){
    if (i == 1){
      temp_names <- paste0(pitc_reduction_years, "_", pitc_reduction_percentage[i])
    }
    if (i > 1){
      temp_names <- append(temp_names, paste0(pitc_reduction_years, "_", pitc_reduction_percentage[i]))
    }
  }
  names(temp) <- temp_names
  baseline <- read.csv("results/baseline.csv")
  bind_rows(temp, .id = "pitc_reduction_year") %>% 
    dplyr::rename(intervention = value) %>% 
    dplyr::left_join(baseline) %>% 
    dplyr::rename(baseline = value) %>% 
    separate(pitc_reduction_year, c("pitc_reduction_year", "test_reduction")) %>% 
    tidyr::pivot_longer(c(intervention, baseline), names_to = "scenario")
}

calc_cumulative <- function(start_year, follow_up_years, df){
  end_year <- start_year + follow_up_years
  df %>% filter(indicator != "AIDSdeathsAdultF", indicator != "AIDSdeathsAdultM", 
                scenario != "percent_change", indicator != "ARTcoverageAdult",
                indicator != "CondomUsage", indicator !="FSWCondomUsage", 
                indicator !="NonFSWCondomUsage", indicator !="PctProtSexActsSW", 
                indicator !="PctSexActsSW", indicator!= "HIVinc15to49",
                year >= start_year,
                year <= end_year,
                pitc_reduction_year == start_year)  %>% 
    group_by(indicator, pitc_reduction_year, scenario, parameter_set, test_reduction, discount) %>% 
    summarise(cumulative = sum(value))
}

calc_all_cumulatives <- function(pitc_reduction_years, follow_up_years, df){
  cumulatives <- lapply(pitc_reduction_years, calc_cumulative, follow_up_years, df)
  names(cumulatives) <- pitc_reduction_years
  all_cumulatives <- bind_rows(cumulatives, .id = "pitc_reduction_year")
}

#### find elimination year ####
# these functions find the elimination year or record not attained and mean+95% CI of incidence at 2100

find_elimination_year <- function(simulation_df, reduction_year, pitc_reduction, future_variable, future_values){
  inc <- simulation_df %>% 
    filter(scenario == "intervention", indicator == "HIVinc15to49",
           pitc_reduction_year == reduction_year, test_reduction == pitc_reduction,
           future_variability == future_variable, future_value == future_values, year > 2020)
  # identify earliest year incidence <0.001 or record not attained
  if (!is.na(filter(inc, mean < 0.001)$mean[1])) {
    HIV_elimination_year <- filter(inc, mean < 0.001)$year[1]
  } else {
    HIV_elimination_year <- NA}
  HIV_elimination_year
}
find_elimination_years <- function(simulation_df){
  future_variable <- unique(simulation_df$future_variability)
  future_values <- unique(simulation_df$future_value)
  pitc_reduction_years <- unique(simulation_df$pitc_reduction_year)
  pitc_reduction_percentages <- unique(simulation_df$test_reduction)
  elimination_years <- data.frame(expand_grid(pitc_reduction_year = pitc_reduction_years, 
                                              pitc_reduction_percentage = pitc_reduction_percentages,
                                              future_variability = future_variable, 
                                              future_value = future_values,
                                              elimination_year = NA))
  input_values <- expand_grid(pitc_reduction_year = pitc_reduction_years,
                              pitc_reduction_percentage = pitc_reduction_percentages,
                              future_variability = future_variable, 
                              future_value = future_values)
  for (i in 1:nrow(elimination_years)){
    elimination_years$elimination_year[i] <- find_elimination_year(simulation_df,
                                                                   reduction_year = input_values$pitc_reduction_year[i],
                                                                   pitc_reduction = input_values$pitc_reduction_percentage[i],
                                                                   future_variable = input_values$future_variability[i], 
                                                                   future_values = input_values$future_value[i])
  }
  elimination_years
}


find_incidences_at_2100 <- function(simulation_df){
  future_variable <- unique(simulation_df$future_variability)
  future_values <- unique(simulation_df$future_value)
  pitc_reduction_years <- unique(simulation_df$pitc_reduction_year)
  pitc_reduction_percentages <- unique(simulation_df$test_reduction)
  incidences_at_2100 <- data.frame(expand_grid(future_variability = future_variable, 
                                               future_value = future_values, 
                                               pitc_reduction_year = pitc_reduction_years,
                                               pitc_reduction_percentage = pitc_reduction_percentages,
                                               mean_incidence_2100 = NA,
                                               lower_ci = NA,
                                               upper_ci = NA))
  input_values <- expand_grid(future_variability = future_variable, 
                              future_value = future_values, 
                              pitc_reduction_year = pitc_reduction_years, 
                              pitc_reduction_percentage = pitc_reduction_percentages)
  
  
  for (i in 1:length(input_values$pitc_reduction_year)){
    inc <- simulation_df %>% 
      filter(scenario == "intervention", 
             indicator == "HIVinc15to49",
             pitc_reduction_year == input_values$pitc_reduction_year[i],
             test_reduction == input_values$pitc_reduction_percentage[i],
             future_variability == input_values$future_variability[i], 
             future_value == input_values$future_value[i], 
             year == 2100)
    incidences_at_2100$mean_incidence_2100[i] <- tail(inc$mean, 1)
    incidences_at_2100$lower_ci[i] <- tail(inc$lower_CI, 1)
    incidences_at_2100$upper_ci[i] <- tail(inc$upper_CI, 1)
  }
  incidences_at_2100
}

find_inc_and_elimination <- function(simulation_df){
  incidences <- find_incidences_at_2100(simulation_df)
  years <- find_elimination_years(simulation_df) 
  inner_join(years, incidences, by = c("future_variability", "future_value", "pitc_reduction_year", "pitc_reduction_percentage"))
}

find_elimination_year_df <- function(df, reduction_year, pitc_reduction, parameter_set_number, scenario_number){
  inc <- df %>% 
    filter(scenario == scenario_number, indicator == "HIVinc15to49",
           pitc_reduction_year == reduction_year, test_reduction == pitc_reduction,
           parameter_set == parameter_set_number, year > 2020)
  # identify earliest year incidence <0.001 or record not attained
  if (!is.na(filter(inc, value < 0.001)$value[1])) {
    HIV_elimination_year <- filter(inc, value < 0.001)$year[1]
  } else {
    HIV_elimination_year <- Inf}
  HIV_elimination_year
}
find_elimination_years_df <- function(df){
  parameter_sets <- unique(df$parameter_set)
  pitc_reduction_years <- unique(df$pitc_reduction_year)
  pitc_reduction_percentages <- unique(df$test_reduction)
  scenarios <- unique(df$scenario)
  elimination_years <- data.frame(expand_grid(pitc_reduction_year = pitc_reduction_years, 
                                              pitc_reduction_percentage = pitc_reduction_percentages,
                                              scenario = scenarios,
                                              parameter_set = parameter_sets,
                                              elimination_year = Inf))
  input_values <- expand_grid(pitc_reduction_year = pitc_reduction_years,
                              pitc_reduction_percentage = pitc_reduction_percentages,
                              scenario = scenarios,
                              parameter_set = parameter_sets)
  for (i in 1:nrow(elimination_years)){
    elimination_years$elimination_year[i] <- find_elimination_year_df(df,
                                                                      reduction_year = input_values$pitc_reduction_year[i],
                                                                      pitc_reduction = input_values$pitc_reduction_percentage[i],
                                                                      scenario_number = input_values$scenario[i],
                                                                      parameter_set_number = input_values$parameter_set[i])
  }
  elimination_years
}

add_elimination_year_to_cumulative <- function(cumulative_values, df){
  elimination_years_prepped <- find_elimination_years_df(df) %>% 
    mutate(indicator = "elimination_year", 
           test_reduction = pitc_reduction_percentage, 
           cumulative = as.numeric(elimination_year)) %>% 
    select(indicator, pitc_reduction_year, scenario, parameter_set, test_reduction, cumulative)
  bind_rows(cumulative_values, elimination_years_prepped)
}





